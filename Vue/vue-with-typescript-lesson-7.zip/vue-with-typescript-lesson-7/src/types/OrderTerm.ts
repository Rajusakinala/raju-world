type OrderTerm = 'title' | 'salary' | 'location'

export default OrderTerm