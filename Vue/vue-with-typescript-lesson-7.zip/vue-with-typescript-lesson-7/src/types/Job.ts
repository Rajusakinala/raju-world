interface Job {
  title: string,
  location: string,
  salary: number,
  id: string
}

export default Job